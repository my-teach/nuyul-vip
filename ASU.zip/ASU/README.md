# ASU
facebook hacking toolkit
<br>
FULL TUTORIAL: https://youtu.be/qZn2rRaHAio
<br><br>
<img src="https://github.com/LOoLzeC/ASU/blob/master/raw/Screenshot_2019-03-02-22-21-28.png"/>
